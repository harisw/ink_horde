<?php
  session_start();
  include "koneksi.php";

  $user_name_up = $_POST['user_name_up_in'];
  $password_up = $_POST['password_up_in'];
  $email_up = $_POST['email_up_in'];

  $query="UPDATE PLAYER SET p_username = '".$user_name_up."',
  p_password = MD5('".$password_up."'), p_email = '".$email_up."'
  WHERE p_id = '".$_SESSION["user_id"]."' ";

  if(mysqli_query($connection, $query))
  {
    header("Location:/ink_horde/dashboard.php");
  }

  else {
    echo "GAGAL!!!";
  }
?>
